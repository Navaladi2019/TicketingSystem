import sys
args=sys.argv[1:]; sys.argv=['x']
exec(open('sec.py').read().split('for c in sys.argv')[0])
F=" AND (r.data->>'p') = 'x'"
def mk(o): return f"SELECT count(*) FROM (SELECT 1 FROM records r {w}{leaf}{F}{' ORDER BY r.updated_at DESC, r.id DESC' if o else ''} LIMIT 1001) c"
def ro(o): return f"SELECT count(*) FROM (SELECT 1 FROM records r {w}{leaf}{' ORDER BY r.updated_at DESC, r.id DESC' if o else ''} LIMIT 1001) c"
for c in args:
    total,ne,ten,width,sc=map(int,c.split(','))
    psql("TRUNCATE records; ALTER TABLE records DROP CONSTRAINT IF EXISTS records_pkey, DROP CONSTRAINT IF EXISTS records_number_key; "+''.join(f"DROP INDEX IF EXISTS records_{i};" for i in IX))
    psql(open('load2.sql').read(),total=total,ne=ne,tenants=ten,width=width,scatter=sc)
    psql(open('idx.sql').read())
    print('##',c,psql(f"select round(100.0*count(*) filter (where tenant_id='{T}')/count(*),1), count(*) filter (where tenant_id<>'{T}') from records").strip(),flush=True)
    for n,q in (('R today',ro(0)),('R ordered',ro(1)),('R+data today',mk(0)),('R+data ordered',mk(1))): print('  ',n,*go(q,True,4),flush=True)
