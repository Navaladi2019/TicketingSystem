import sys
args=sys.argv[1:]; sys.argv=['x']
exec(open('sec2.py').read().split('for c in args')[0].replace("args=sys.argv[1:]; sys.argv=['x']",""))
def ex(q): 
    s=f"SET app.tenant_id='{T}'; SET ROLE nava_app; EXPLAIN (ANALYZE,BUFFERS,TIMING OFF,SUMMARY OFF) {q};"
    print(psql(s))
psql("TRUNCATE records; ALTER TABLE records DROP CONSTRAINT IF EXISTS records_pkey, DROP CONSTRAINT IF EXISTS records_number_key; "+''.join(f"DROP INDEX IF EXISTS records_{i};" for i in IX))
psql(open('load2.sql').read(),total=66000,ne=33366,tenants=100,width=1024,scatter=1); psql(open('idx.sql').read())
ex(mk(1))
print('NO R, data filter'); ex(f"SELECT count(*) FROM (SELECT 1 FROM records r {w}(r.data->>'p')='x' LIMIT 1001) c")
