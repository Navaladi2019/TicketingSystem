-- :total rows, :ne rows of the type, :tenants (1 = one tenant), :width bytes of data, :ord heap order key
DROP TABLE IF EXISTS tmp; 
INSERT INTO records SELECT md5('t'||tn)::uuid, gen_random_uuid(), 1, CASE WHEN isconc THEN md5('conc')::uuid ELSE md5('d'||tn)::uuid END, 1,
  (CASE WHEN isconc THEN 'C-' ELSE 'P-' END)||g, CASE WHEN g%2=0 OR isconc THEN 'open' ELSE 'closed' END, md5('u'||g%997)::uuid, md5('a'||g%499)::uuid, md5('gr'||g%50)::uuid, md5('u'||g%997)::uuid,
  now()-((g::bigint*7919)%100003)*interval '1 s', now()-((g::bigint*104729)%1000003)*interval '1 s',
  CASE WHEN :width=0 THEN '{}'::jsonb ELSE jsonb_build_object('d', repeat(md5(g::text||'x'), :width/32)) END, NULL, 0,
  CASE WHEN isconc THEN md5('o'||g%2000)::uuid ELSE md5('s'||g%10111)::uuid END
FROM (SELECT g, g <= :ne AS isconc, CASE WHEN g <= :ne THEN 1 WHEN :tenants >= 100 THEN CASE WHEN hashint4(g) & 127 < :tenants - 100 THEN 1 ELSE 2 + g % 19 END ELSE 1 + g % :tenants END AS tn FROM generate_series(1,:total) g) x
ORDER BY CASE WHEN :scatter = 1 THEN hashtext(g::text) ELSE g END;
