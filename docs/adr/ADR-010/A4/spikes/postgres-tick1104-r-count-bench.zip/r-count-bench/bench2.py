import sys,json
from bench import *
OR=f"SELECT count(*) FROM (SELECT 1 FROM records r {w}{leaf} ORDER BY r.updated_at DESC, r.id DESC LIMIT 1001) c"
def load(total,ne,tenants,width,scatter):
    psql("TRUNCATE records; ALTER TABLE records DROP CONSTRAINT IF EXISTS records_pkey, DROP CONSTRAINT IF EXISTS records_number_key; "+''.join(f"DROP INDEX IF EXISTS records_{i};" for i in 'list_updated list_created list_state list_group list_requester list_assignee list_group_state org_unit'.split()))
    psql(open('load.sql').read(),total=total,ne=ne,tenants=tenants,width=width,scatter=scatter)
    psql("SET maintenance_work_mem='512MB';"+open('idx.sql').read())
def generic(q,name):
    body=q.replace(f"'{T}'::uuid","$1::uuid").replace(f"'{C}'::uuid","$2::uuid").replace(f"'{{{S}}}'::uuid[]","$3::uuid[]")
    s=f"SET effective_cache_size='6GB'; SET app.tenant_id='{T}'; SET ROLE nava_app; SET plan_cache_mode=force_generic_plan; PREPARE p AS {body};"+"".join(f"EXPLAIN (ANALYZE,BUFFERS,TIMING OFF,FORMAT JSON) EXECUTE p('{T}','{C}','{{{S}}}'); SELECT '~~~';" for _ in range(5))
    ps=[json.loads(x)[0] for x in psql(s).split('~~~') if x.strip()]
    ts=sorted(p['Execution Time'] for p in ps[1:]); sc=scan(ps[-1]['Plan'])
    return name,sc[0],round(ts[len(ts)//2],1),ps[-1]['Plan']['Total Cost']
for c in sys.argv[1:]:
    a=tuple(map(int,c.split(','))); load(*a); print('##',a,flush=True)
    for n,q,pre in (('R count',R,''),('seq only',R,'SET enable_indexscan=off;SET enable_bitmapscan=off;'),('ordered count',OR,'')):
        print(' ',n,run(q,pre),flush=True)
    for n,q in (('gen R count',R),('gen ordered',OR),('gen page',PAGE)): print(' ',generic(q,n),flush=True)
