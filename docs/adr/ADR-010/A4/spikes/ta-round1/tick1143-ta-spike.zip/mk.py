for m in ('m500','m0'):
    o=open(f'W1-{m}-true.sql').read(); t=open(f'W1-{m}-false.sql').read()
    head,q=o.split('EXPLAIN (ANALYZE, BUFFERS) ',1)
    _,tq=t.split('EXPLAIN (ANALYZE, BUFFERS) ',1)
    inner=q[q.index('(SELECT 1 FROM records r')+1:q.rindex(') c')]
    page=inner.replace('SELECT 1 FROM','SELECT r.* FROM',1).replace('LIMIT 1001','LIMIT 51')
    E='EXPLAIN (ANALYZE, BUFFERS) '
    for arm,c in (('today',tq),('ordered',q),('cov',tq)):
        open(f'S-{m}-{arm}.sql','w').write(head+E+page+';\n'+E+c)       # S21 order: page, count
        open(f'M-{m}-{arm}.sql','w').write(head+E+c+E+page+';\n')         # main order: count, page
