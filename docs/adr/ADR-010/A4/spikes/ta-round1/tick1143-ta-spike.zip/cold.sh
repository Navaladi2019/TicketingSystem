#!/bin/bash
# cold cache: stop PG, drop this volume's files from the VM page cache (posix_fadvise DONTNEED), start, run once
export MSYS_NO_PATHCONV=1
for r in 1 2 3 4; do for q in m500-false m500-true m0-false m0-true; do
  docker stop -t 60 tick1143-pg >/dev/null
  docker run --rm -v tick1143-data:/d --entrypoint bash postgres:16.10 -c 'find /d/base /d/global -type f -size +0 | while read f; do dd if="$f" iflag=nocache count=0 status=none; done'
  docker start tick1143-pg >/dev/null
  until docker exec tick1143-pg pg_isready -h 127.0.0.1 -U pgadmin -d postgres >/dev/null 2>&1; do sleep 0.5; done; sleep 2
  echo "## r$r $q $(docker exec -i tick1143-pg psql -qAtX -U pgadmin -d nava < W1-$q.sql | grep -E 'Scan|Buffers|I/O|Execution|Sort' | sed 's/  */ /g' | tr '\n' ';')"
done; done
