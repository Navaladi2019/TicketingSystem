export MSYS_NO_PATHCONV=1
one() {
  docker stop -t 60 tick1143-pg >/dev/null
  docker run --rm -v tick1143-data:/d --entrypoint bash postgres:16.10 -c 'find /d/base /d/global -type f -size +0 | while read f; do dd if="$f" iflag=nocache count=0 status=none; done'
  docker start tick1143-pg >/dev/null
  until docker exec tick1143-pg pg_isready -h 127.0.0.1 -U pgadmin -d postgres >/dev/null 2>&1; do sleep 0.5; done; sleep 1
  echo "$1 $2: $(docker exec -i tick1143-pg psql -qAtX -U pgadmin -d nava < $1-$2.sql | grep -E 'on records r|Execution|Heap Fetches' | sed -E 's/  */ /g; s/\(cost[^)]*\)//; s/\(never.*//' | tr '\n' ';')"
}
for r in 1 2 3; do for a in $1; do one ${a%%:*} ${a##*:}; done; done
