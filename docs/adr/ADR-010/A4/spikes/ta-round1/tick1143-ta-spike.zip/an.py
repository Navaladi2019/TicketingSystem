import re
for f in ('out.log',):
    w=None;rows={}
    for l in open(f,encoding='utf8'):
        m=re.match(r'## (W\d)',l)
        if m: w=m[1]
        m=re.match(r'  (\S.*?)\s+(today|ordered|todayA/A|ord m=0)\s+med=\s*([\d.]+) p90=\s*[\d.]+ n=(\d+)',l)
        if m: rows.setdefault((w,m[1].strip()),{})[m[2]]=(float(m[3]),int(m[4]))
    print(f)
    for k,v in rows.items():
        t,o=v['today'],v['ordered']
        z=v.get('ord m=0');a=v.get('todayA/A')
        print(k, 'today %.1f ord %.1f d=%+.1f'%(t[0],o[0],o[0]-t[0]), ('AA=%.1f ord-m0=%+.1f%s'%(abs(a[0]-t[0]),o[0]-z[0],' BREACH' if o[0]-z[0]>10 else '')) if z else ('' if o[0]-t[0]<=15 else 'A1>15'), '' if t[1]==o[1] else 'TOTAL DIFFERS')
