//go:build integration

// TICK-1143 spike, throwaway, never committed.
package server_test

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"

	"github.com/Navaladi2019/TicketingSystem/internal/authz"
	"github.com/Navaladi2019/TicketingSystem/internal/identity"
	"github.com/Navaladi2019/TicketingSystem/internal/records/pipeline"
	"github.com/Navaladi2019/TicketingSystem/internal/records/store"
	"github.com/Navaladi2019/TicketingSystem/internal/tenancy"
)

type sCell struct {
	name                        string
	rows, ne, tenants, width    int
	scatter, handler, cov, cold bool
}

func TestSpike1143(t *testing.T) {
	e := newPatchEnv(t)
	ctx := context.Background()
	exec := func(sql string, args ...any) {
		t.Helper()
		if _, err := e.super.Exec(ctx, sql, args...); err != nil {
			t.Fatalf("%s: %v", sql, err)
		}
	}
	out := func(f string, a ...any) { fmt.Printf(f+"\n", a...) }
	in := e.mustCreateRec(t, "user-a", "job", "s1143", `{"short_description": "in"}`)
	var def uuid.UUID
	if err := e.super.QueryRow(ctx, `SELECT entity_definition_id FROM records WHERE tenant_id=$1 AND id=$2`, e.a.id, in.ID).Scan(&def); err != nil {
		t.Fatal(err)
	}
	user := identity.Principal{TenantID: e.a.id, PrincipalID: e.a.user.PrincipalID}
	id := func(s string) uuid.UUID {
		var u uuid.UUID
		if err := e.super.QueryRow(ctx, `SELECT md5($1::text)::uuid`, s).Scan(&u); err != nil {
			t.Fatal(err)
		}
		return u
	}
	// trees: pad 10,100 units; g* 11 each, so pad+g* is 10,111; o 2,000; p2 10,100.
	exec(`SET session_replication_role = replica`)
	roots := map[string]uuid.UUID{}
	for _, tr := range []struct {
		p string
		n int
	}{{"pad", 10100}, {"p2", 10100}, {"gz", 11}, {"ga", 11}, {"gb", 11}, {"gc", 11}, {"gd", 11}, {"ge", 11}, {"o", 2000}} {
		exec(`INSERT INTO org_units (tenant_id,id,parent_id,keycloak_group_id,name)
			SELECT $1, md5($2::text||g)::uuid, CASE WHEN g>0 THEN md5($2::text||(g-1)/10)::uuid END, 'k-'||$2::text||'-'||g, $2::text||'-'||g FROM generate_series(0,$3::int-1) g`, e.a.id, tr.p, tr.n)
		exec(`INSERT INTO org_unit_closure (tenant_id,ancestor_id,descendant_id)
			WITH RECURSIVE c(d,a) AS (SELECT g,g FROM generate_series(0,$3::int-1) g UNION ALL SELECT d,(a-1)/10 FROM c WHERE a>0)
			SELECT $1, md5($2::text||a)::uuid, md5($2::text||d)::uuid FROM c`, e.a.id, tr.p, tr.n)
		roots[tr.p] = id(tr.p + "0")
	}
	exec(`RESET session_replication_role`)
	exec(`ANALYZE org_units`)
	exec(`VACUUM ANALYZE org_unit_closure`)
	of := func(ks ...string) string {
		var q []string
		for _, k := range ks {
			q = append(q, `"`+roots[k].String()+`"`)
		}
		return `{"under":{"of":[` + strings.Join(q, ",") + `]}}`
	}
	self := `{"cmp":{"column":"requester_id","op":"eq","caller":"self"}}`
	open := `{"cmp":{"column":"state","op":"eq","values":["open"]}}`
	mc := []struct{ name, u string }{
		{"m=0", of("pad", "gz")}, {"m=51", of("pad", "ga")}, {"m=500", of("pad", "gb")},
		{"m=1000", of("pad", "gc")}, {"m=1500 spread", of("pad", "gd")}, {"m=1500 oldest", of("pad", "ge")},
		{"m=all", of("pad", "o", "gz", "ga", "gb", "gc", "gd", "ge")},
	}
	stmt := func(when string, ordered bool) (string, []any) {
		d, err := authz.Decode([]byte(`{"format":2,"conditions":[],"policies":[{"name":"u","ops":["read"],"when":` + when + `}]}`))
		if err != nil {
			t.Fatal(err)
		}
		pol := &authz.Policy{Version: 1, EntityType: "job", Document: d}
		var sql string
		var args []any
		if err := tenancy.InTenantTx(ctx, e.pool, e.a.id, func(tx pgx.Tx) error {
			b, err := authz.ResolveUnder(ctx, tx, pol, user)
			if err != nil {
				return err
			}
			r := authz.ReadListShaped(b, user, "r", 2, authz.FixedListShapes(authz.ShapeRecords))
			q := pipeline.ListQuery{TenantID: e.a.id, DefinitionID: def, Where: "true", Args: r.Args, Branches: r.Branches,
				CountBranches: r.CountBranches, Materialize: r.Materialize, SortColumn: "updated_at", Desc: true, Limit: 51}
			if r.Branches == nil {
				q.Where, q.CountWhere = r.Where, r.CountWhere
			}
			for _, d := range r.Drivers {
				q.CountDrivers = append(q.CountDrivers, pipeline.CountDriver{From: d.From, Key: d.Key})
			}
			store.SpikeOrdered.Store(ordered)
			sql = pipeline.CountStatement(q)
			store.SpikeOrdered.Store(false)
			args = append([]any{q.TenantID, q.DefinitionID}, q.Args...)
			return nil
		}); err != nil {
			t.Fatal(err)
		}
		return sql, args
	}
	var planOf func(n map[string]any, acc *[]string)
	planOf = func(n map[string]any, acc *[]string) {
		ty, _ := n["Node Type"].(string)
		rel, _ := n["Relation Name"].(string)
		ix, _ := n["Index Name"].(string)
		if ty == "Sort" || strings.HasPrefix(ty, "Gather") || ty == "Incremental Sort" {
			*acc = append(*acc, fmt.Sprintf("%s(%v w=%v)", ty, n["Sort Method"], n["Workers Launched"]))
		}
		if rel == "records" || (strings.Contains(ix, "records_") && ty == "Bitmap Index Scan") {
			s := ty + " " + ix
			if n["Actual Loops"] == 0.0 {
				s += " NEVER"
			}
			*acc = append(*acc, fmt.Sprintf("%s rows=%v rem=%v", s, n["Actual Rows"], n["Rows Removed by Filter"]))
		}
		if ps, ok := n["Plans"].([]any); ok {
			for _, p := range ps {
				planOf(p.(map[string]any), acc)
			}
		}
	}
	type arm struct {
		sql  string
		args []any
	}
	pct := func(d []float64, p float64) float64 {
		s := append([]float64{}, d...)
		sort.Float64s(s)
		return s[min(len(s)-1, int(float64(len(s))*p))]
	}
	bench := func(tag string, names []string, arms []arm) {
		ts := make([][]float64, len(arms))
		cnt := make([]int64, len(arms))
		plans, bufs := make([]string, len(arms)), make([]string, len(arms))
		if err := tenancy.InTenantTx(ctx, e.pool, e.a.id, func(tx pgx.Tx) error {
			for r := -2; r < 21; r++ {
				for i, a := range arms {
					s := time.Now()
					if err := tx.QueryRow(ctx, a.sql, a.args...).Scan(&cnt[i]); err != nil {
						return err
					}
					if r >= 0 {
						ts[i] = append(ts[i], float64(time.Since(s).Microseconds())/1000)
					}
				}
			}
			for i, a := range arms {
				var raw []byte
				if err := tx.QueryRow(ctx, "EXPLAIN (ANALYZE, BUFFERS, TIMING OFF, FORMAT JSON) "+a.sql, a.args...).Scan(&raw); err != nil {
					return err
				}
				var p []map[string]any
				if err := json.Unmarshal(raw, &p); err != nil {
					return err
				}
				var acc []string
				root := p[0]["Plan"].(map[string]any)
				planOf(root, &acc)
				plans[i] = strings.Join(acc, " | ")
				bufs[i] = fmt.Sprintf("cost=%v buf=%v+%v", root["Total Cost"], root["Shared Hit Blocks"], root["Shared Read Blocks"])
			}
			return nil
		}); err != nil {
			t.Fatal(err)
		}
		for i := range arms {
			out("  %-16s %-9s med=%6.1f p90=%6.1f n=%d  %s  [%s]", tag, names[i], pct(ts[i], .5), pct(ts[i], .9), cnt[i], bufs[i], plans[i])
		}
	}
	version := 0
	publish := func(when string) {
		t.Helper()
		got := e.access(t, http.MethodGet, accessPath, "admin-a", "", "", "")
		version++
		if rec := e.access(t, http.MethodPut, accessPath, "admin-a", s31Key("sp"+strconv.Itoa(version)), got.Header().Get("ETag"),
			`{"rules": {"format": 2, "conditions": [], "policies": [{"name": "u", "ops": ["read"], "when": `+when+`}]}}`); rec.Code != http.StatusOK {
			t.Fatalf("publish = %d %s", rec.Code, rec.Body)
		}
	}
	load := func(path string, clients, n int) []float64 {
		ch := make(chan int, n)
		for i := range n {
			ch <- i
		}
		close(ch)
		var mu sync.Mutex
		var ts []float64
		var wg sync.WaitGroup
		for range clients {
			wg.Add(1)
			go func() {
				defer wg.Done()
				for range ch {
					s := time.Now()
					rec := e.do(t, http.MethodGet, path, "user-a", "", "")
					d := float64(time.Since(s).Microseconds()) / 1000
					if rec.Code != 200 {
						t.Errorf("%d %s", rec.Code, rec.Body)
					}
					mu.Lock()
					ts = append(ts, d)
					mu.Unlock()
				}
			}()
		}
		wg.Wait()
		return ts
	}
	cells := []sCell{
		{"W1 1 tenant 250k x 1KB Ne=33366", 250000, 33366, 1, 1024, true, true, true, true},
		{"W2 1 tenant 800k empty Ne=33366", 800000, 33366, 1, 0, true, true, true, true},
		{"W3 20 tenants 400k x 1KB Ne=33366", 400000, 33366, 20, 1024, true, false, false, false},
		{"W4 3 tenants 620k empty contiguous Ne=20000", 620000, 20000, 3, 0, false, false, false, false},
		{"W5 1 tenant 70k empty Ne=33366 (low ratio)", 70000, 33366, 1, 0, true, false, false, false},
		{"W6 50 tenants 800k empty Ne=20000 (small share)", 800000, 20000, 50, 0, true, false, false, false},
		{"W7 1 tenant 420k empty contiguous Ne=20000 (CI-4)", 420000, 20000, 1, 0, false, false, false, false},
	}
	only := os.Getenv("SPIKE_ONLY")
	for _, c := range cells {
		if only != "" && !strings.Contains(only, c.name[:2]) {
			continue
		}
		exec(`SET session_replication_role = replica`)
		exec(`TRUNCATE records CASCADE`)
		order := "g"
		if c.scatter {
			order = "hashtext(g::text)"
		}
		exec(`INSERT INTO records (tenant_id,id,entity_definition_id,version,schema_version,number,state,requester_id,assignee_id,assignment_group_id,org_unit_id,created_at,updated_at,data)
		SELECT CASE WHEN tn=1 THEN $1::uuid ELSE md5('t'||tn)::uuid END, gen_random_uuid(), CASE WHEN isc THEN $2::uuid ELSE md5('d'||tn)::uuid END, 1, 1, (CASE WHEN isc THEN 'C-' ELSE 'P-' END)||g,
		 CASE WHEN g%2=0 THEN 'open' ELSE 'closed' END,
		 CASE WHEN NOT isc AND g%10<3 THEN $3::uuid ELSE md5('u'||g%997)::uuid END, md5('a'||g%499)::uuid, md5('gr'||g%50)::uuid,
		 CASE WHEN NOT isc THEN md5('pad'||g%10100)::uuid WHEN g<=51 THEN md5('ga'||g%11)::uuid WHEN g<=551 THEN md5('gb'||g%11)::uuid WHEN g<=1551 THEN md5('gc'||g%11)::uuid
		   WHEN g<=3051 THEN md5('gd'||g%11)::uuid WHEN g<=4551 THEN md5('ge'||g%11)::uuid ELSE md5('o'||g%2000)::uuid END,
		 now()-((g::bigint*7919)%100003)*interval '1 s',
		 CASE WHEN isc AND g BETWEEN 3052 AND 4551 THEN now()-(2000000+g)*interval '1 s' ELSE now()-((g::bigint*104729)%1000003)*interval '1 s' END,
		 CASE WHEN $4::int=0 THEN '{}'::jsonb ELSE jsonb_build_object('short_description', repeat(md5(g::text||'x'), $4::int/32)) END
		FROM (SELECT g, g<=$5::int AS isc, CASE WHEN g<=$5::int THEN 1 ELSE 1+g%$6::int END AS tn FROM generate_series(1,$7::int) g) x ORDER BY `+order,
			e.a.id, def, user.PrincipalID, c.width, c.ne, c.tenants, c.rows)
		exec(`RESET session_replication_role`)
		exec(`SET maintenance_work_mem='512MB'`)
		exec(`REINDEX TABLE records`)
		exec(`VACUUM ANALYZE records`)
		exec(`CHECKPOINT`)
		exec(`DELETE FROM entity_record_estimates WHERE tenant_id=$1 AND entity_definition_id=$2`, e.a.id, def)
		exec(`INSERT INTO entity_record_estimates (tenant_id,entity_definition_id,live_records,refreshed_at) VALUES ($1,$2,$3,now())`, e.a.id, def, c.ne)
		var mb, ixs int64
		_ = e.super.QueryRow(ctx, `SELECT pg_relation_size('records')/1048576, pg_relation_size('records_list_updated')/1024`).Scan(&mb, &ixs)
		out("\n## %s heap=%dMB list_updated=%dKB %s", c.name, mb, ixs, time.Now().Format("15:04:05"))
		zeroSQL, zeroArgs := stmt(mc[0].u, true)
		for _, m := range mc {
			a, aa := stmt(m.u, false)
			o, oa := stmt(m.u, true)
			bench(m.name, []string{"today", "ordered", "todayA/A", "ord m=0"}, []arm{{a, aa}, {o, oa}, {a, aa}, {zeroSQL, zeroArgs}})
		}
		for _, b := range []struct{ name, when string }{
			{"B self|R m=0", `{"any":[` + self + `,` + mc[0].u + `]}`},
			{"B R|self m=500", `{"any":[` + mc[2].u + `,` + self + `]}`},
			{"B R|R 500|1000", `{"any":[` + mc[2].u + `,` + of("p2", "gc") + `]}`},
			{"B R|self m=all", `{"any":[` + mc[6].u + `,` + self + `]}`},
			{"B R|R+open m=0", `{"any":[` + mc[0].u + `,{"all":[` + open + `,` + of("p2", "gz") + `]}]}`},
			{"L5 R&self m=0", `{"all":[` + mc[6].u + `,` + self + `]}`},
		} {
			a, aa := stmt(b.when, false)
			o, oa := stmt(b.when, true)
			if a == o {
				out("  %s: text unchanged", b.name)
			}
			bench(b.name, []string{"today", "ordered"}, []arm{{a, aa}, {o, oa}})
		}
		if c.handler {
			for _, h := range []struct {
				name, u string
				page2   bool
			}{{"H m=500 p1", mc[2].u, false}, {"H m=500 p2", mc[2].u, true}, {"H m=51 p1", mc[1].u, false}} {
				publish(h.u)
				path := "/api/v1/records/job?limit=50"
				rec := e.do(t, http.MethodGet, path, "user-a", "", "")
				var l recordsShapeList
				if err := json.Unmarshal(rec.Body.Bytes(), &l); err != nil || rec.Code != 200 {
					t.Fatalf("%d %s", rec.Code, rec.Body)
				}
				if h.page2 {
					path += "&cursor=" + *l.NextCursor
				}
				res := map[string][]float64{}
				for range 3 {
					for _, ord := range []bool{false, true} {
						store.SpikeOrdered.Store(ord)
						load(path, 8, 16)
						k := fmt.Sprintf("%v/8", ord)
						res[k] = append(res[k], load(path, 8, 160)...)
						k = fmt.Sprintf("%v/1", ord)
						res[k] = append(res[k], load(path, 1, 30)...)
					}
				}
				store.SpikeOrdered.Store(false)
				for _, k := range []string{"false/1", "true/1", "false/8", "true/8"} {
					out("  %-16s ordered=%-8s p50=%6.1f p95=%6.1f n=%d total=%d", h.name, k, pct(res[k], .5), pct(res[k], .95), len(res[k]), l.Total)
				}
			}
		}
		if c.cold {
			for _, k := range []int{0, 2} {
				for _, ord := range []bool{false, true} {
					s, a := stmt(mc[k].u, ord)
					for i := len(a) - 1; i >= 0; i-- {
						v := fmt.Sprintf("'%v'", a[i])
						if ss, ok := a[i].([]string); ok {
							v = "'{" + strings.Join(ss, ",") + "}'"
						}
						s = strings.ReplaceAll(s, "$"+strconv.Itoa(i+1), v)
					}
					name := fmt.Sprintf("%s/%s-%s-%v.sql", os.Getenv("SPIKE_DIR"), c.name[:2], map[int]string{0: "m0", 2: "m500"}[k], ord)
					body := "SET app.tenant_id='" + e.a.id.String() + "'; SET ROLE nava_app;\nEXPLAIN (ANALYZE, BUFFERS) " + s + ";\n"
					if err := os.WriteFile(name, []byte(body), 0o600); err != nil {
						t.Fatal(err)
					}
				}
			}
		}
		if c.cov && os.Getenv("SPIKE_COV") != "" {
			s := time.Now()
			exec(`CREATE INDEX zz_cov ON records (tenant_id, entity_definition_id, updated_at DESC, id DESC) INCLUDE (org_unit_id)`)
			b := time.Since(s)
			exec(`VACUUM ANALYZE records`)
			var kb int64
			_ = e.super.QueryRow(ctx, `SELECT pg_relation_size('zz_cov')/1024`).Scan(&kb)
			out("  covering: build %v size %dKB vs %dKB", b, kb, ixs)
			for _, k := range []int{0, 2} {
				a, aa := stmt(mc[k].u, false)
				o, oa := stmt(mc[k].u, true)
				bench("cov "+mc[k].name, []string{"today", "ordered"}, []arm{{a, aa}, {o, oa}})
			}
			if c.handler {
				for _, pg2 := range []bool{false, true} {
					publish(mc[2].u)
					path := "/api/v1/records/job?limit=50"
					rec := e.do(t, http.MethodGet, path, "user-a", "", "")
					var l recordsShapeList
					_ = json.Unmarshal(rec.Body.Bytes(), &l)
					if pg2 {
						path += "&cursor=" + *l.NextCursor
					}
					load(path, 8, 16)
					r8, r1 := load(path, 8, 480), load(path, 1, 90)
					out("  H cov m=500 page2=%v /1 p50=%.1f p95=%.1f /8 p50=%.1f p95=%.1f", pg2, pct(r1, .5), pct(r1, .95), pct(r8, .5), pct(r8, .95))
				}
			}
			exec(`SET session_replication_role = replica`)
			exec(`UPDATE records SET updated_at = now() WHERE entity_definition_id = $1 AND hashtext(id::text) % 20 = 0`, def)
			exec(`RESET session_replication_role`)
			a, aa := stmt(mc[2].u, false)
			o, oa := stmt(mc[2].u, true)
			bench("cov 5% updated", []string{"today", "ordered"}, []arm{{a, aa}, {o, oa}})
			exec(`DROP INDEX zz_cov`)
		}
	}
}
