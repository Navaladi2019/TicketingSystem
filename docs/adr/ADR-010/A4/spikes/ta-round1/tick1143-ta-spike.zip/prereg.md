Written before any cell ran.
T-1. Section 5 thresholds A1/A2/A3/A4 applied as written. None changed.
T-2. A2 names no m, page or client count. Fixed here: 8 clients, closed loop, in-process handler, no transport (the P3-36 method, NAVA_PERF_CLIENTS=8). Scored on m=500 page 1 and m=500 page 2. m=0 informational. 1 client also reported.
T-3. A3's "+10 ms" is close to this host's noise. Method (not threshold): the cell, today's text, today's text again (A/A) and the ordered m=0 count run round robin in one transaction, 21 timed executions each, median. A breach counts if the A/A spread of that row is below 10 ms.
T-4. A1's total is checked: ordered total = today's total in every row.
Hypothesis: for every m the ordered count plans as Index Scan records_list_updated and costs at most the ordered m=0 count + 10 ms.
