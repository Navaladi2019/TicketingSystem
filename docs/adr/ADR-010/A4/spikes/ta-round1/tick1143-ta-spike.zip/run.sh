#!/bin/bash
cd "$(dirname "$0")"; mkdir lock.d || exit 1
export NAVA_TEST_PG_URL=postgres://pgadmin:bench@127.0.0.1:65071/postgres SPIKE_COV=1 SPIKE_DIR=$(cygpath -m $PWD)
# other database containers on the host (by name), ignoring my own and multica's
others() { docker stats --no-stream --format '{{.Name}} {{.CPUPerc}}' | grep -vE '^(tick1143-pg|multica-[a-z]+-1) ' | awk '{p=$2+0; if (p>15) printf "%s=%s ", $1, $2}'; }
( while [ ! -f stop ]; do echo "$(date +%H:%M:%S) $(others)"; sleep 6; done ) >> contention.log &
for w in "$@"; do
  quiet=0; for i in $(seq 1 90); do [ -z "$(others)" ] && quiet=$((quiet+1)) || quiet=0; [ $quiet -ge 3 ] && break; sleep 2; done
  echo "=== $w start $(date +%H:%M:%S) others=[$(others)]" >> out.log
  ( cd ../TicketingSystem/internal/server && SPIKE_ONLY=$w ../../../scratch/spike.exe -test.run '^TestSpike1143$' -test.timeout 60m ) >> out.log 2>&1
  echo "=== $w end $(date +%H:%M:%S) others=[$(others)]" >> out.log
done
touch stop; echo ALLDONE >> out.log
