from plans import *
L=leaf(h('s0')); X=h('u5'); req=f"r.requester_id = '{X}'::uuid"; neg=f"({req}) IS NOT TRUE"
for name,c in (('CI-4',(200000,33366,150000,0,0)),('CI-3',(620000,20000,220000,0,0))):
    load(*c,cover=True)
    print(name,'R first, no negation',describe(explain(union([arm(L,0),arm(f"{req} AND ({L}) IS NOT TRUE",0)]))))
    print(name,'requester first, D3 ordered R arm',describe(explain(union([arm(req,0),arm(f"{L} AND {neg}",1)]))))
