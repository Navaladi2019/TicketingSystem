from plans import *
L=leaf(h('s0')); L2=leaf(h('w0')); X=h('u5'); req=f"r.requester_id = '{X}'::uuid"; neg=f"({req}) IS NOT TRUE"
def nodes(p,acc=None,depth=0):
    acc=[] if acc is None else acc
    acc.append((depth,p['Node Type'],p.get('Index Name',p.get('Relation Name','')),p.get('Parent Relationship',''),round(p['Startup Cost']),round(p['Total Cost']),p['Plan Rows']))
    for c in p.get('Plans',[]): nodes(c,acc,depth+1)
    return acc
def rec(p):
    return [n for n in nodes(p) if n[2].startswith('records')]
def sub(p):
    return [n for n in nodes(p) if n[3]=='SubPlan']
for name,c in (('CI-4 200k/33366/share75 contiguous',(200000,33366,150000,0,0)),('CI-4 scattered',(200000,33366,150000,0,1)),('CI-3 620k/20000/3 tenants',(620000,20000,220000,0,0))):
  for rep in range(2):
    for cover in (True,False):
        load(*c,cover=cover)
        print('##',name,'rep',rep,'covering' if cover else 'today index',flush=True)
        for nm,LL in (('10111',L),('20222',L2)):
            q=cnt(LL,0); p=explain(q); off=explain(q,'SET enable_indexonlyscan=off;')
            print('  ',nm,'chosen',describe(p),'| IOS off',describe(off),'ratio %.2f'%(off['Total Cost']/p['Total Cost']))
            print('      records node chosen',rec(p),'| IOS off',rec(off),'| subplan chosen',sub(p),'| subplan IOS off',sub(off))
        if cover:
            print('   CI-5 req+R',describe(explain(union([arm(req,0),arm(f"{L} AND {neg}",0)]))))
