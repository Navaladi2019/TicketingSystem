import subprocess,sys,json
sys.path.insert(0,'.')
import bench
bench.P[3]='tick1143-sec'
from bench import *
OR=f"SELECT count(*) FROM (SELECT 1 FROM records r {w}{leaf} ORDER BY r.updated_at DESC, r.id DESC LIMIT 1001) c"
ST=f"SELECT count(*) FROM (SELECT 1 FROM records r {w}r.state='closed' LIMIT 1001) c"
RQ=f"SELECT count(*) FROM (SELECT 1 FROM records r {w}{leaf} AND r.state='closed' ORDER BY r.updated_at DESC, r.id DESC LIMIT 1001) c"
IX='list_updated list_created list_state list_group list_requester list_assignee list_group_state org_unit'.split()
def nodes(n,d=0):
    out=[]
    if n.get('Relation Name')=='records' or n['Node Type'] in('Sort','Incremental Sort','Gather','Gather Merge','Bitmap Index Scan'): out.append((n['Node Type']+' '+n.get('Index Name','')+(' hashed' if 'hashed' in n.get('Filter','') else ''), n['Plan Rows'],round(n['Total Cost']),n.get('Actual Rows'),n.get('Rows Removed by Filter')))
    for k in n.get('Plans',[]): out+=nodes(k)
    return out
def go(q,ana,rpc):
    s=f"SET random_page_cost={rpc}; SET app.tenant_id='{T}'; SET ROLE nava_app; EXPLAIN ({'ANALYZE,BUFFERS,TIMING OFF,' if ana else ''}FORMAT JSON) {q};"
    p=json.loads(psql(s))[0]['Plan']
    b=(p.get('Shared Hit Blocks',0)+p.get('Shared Read Blocks',0)) if ana else None
    return nodes(p),b
psql(open('schema.sql').read())
for c in sys.argv[1:]:
    total,ne,ten,width,sc=map(int,c.split(','))
    psql("TRUNCATE records; ALTER TABLE records DROP CONSTRAINT IF EXISTS records_pkey, DROP CONSTRAINT IF EXISTS records_number_key; "+''.join(f"DROP INDEX IF EXISTS records_{i};" for i in IX))
    psql(open('load2.sql').read(),total=total,ne=ne,tenants=ten,width=width,scatter=sc)
    psql("SET maintenance_work_mem='256MB';"+open('idx.sql').read())
    sh=psql(f"select round(100.0*count(*) filter (where tenant_id='{T}')/count(*),1), count(*) filter (where tenant_id<>'{T}') from records").strip()
    print('##',c,'share%|other-tenant rows',sh,flush=True)
    for rpc in (4,):
      for n,q in (('R today',R),('R ordered',OR)):
        print('  rpc',rpc,n,*go(q,rpc==4,rpc),flush=True)
