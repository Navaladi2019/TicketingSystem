import sys
args=sys.argv[1:]; sys.argv=['x']
exec(open('sec.py').read().split('for c in sys.argv')[0])
F=''' AND (r.data @> '{"p":"x"}'::jsonb OR NOT (r.data ? 'p'))'''
def q(o,f): return f"SELECT count(*) FROM (SELECT 1 FROM records r {w}{leaf}{f}{' ORDER BY r.updated_at DESC, r.id DESC' if o else ''} LIMIT 1001) c"
COV="DROP INDEX records_list_updated; CREATE INDEX records_list_updated ON records (tenant_id, entity_definition_id, updated_at DESC, id DESC) INCLUDE (org_unit_id); VACUUM ANALYZE records;"
for c in args:
    total,ne,ten,width,sc=map(int,c.split(','))
    psql("TRUNCATE records; ALTER TABLE records DROP CONSTRAINT IF EXISTS records_pkey, DROP CONSTRAINT IF EXISTS records_number_key; "+''.join(f"DROP INDEX IF EXISTS records_{i};" for i in IX))
    psql(open('load3.sql').read(),total=total,ne=ne,tenants=ten,width=width,scatter=sc)
    psql(open('idx.sql').read()); psql(COV)
    print('##',c,psql(f"select round(100.0*count(*) filter (where tenant_id='{T}')/count(*),1), count(*) filter (where tenant_id<>'{T}'), count(*) filter (where tenant_id='{T}') from records").strip(),flush=True)
    for n,s in (('cov, no filter',q(0,'')),('cov, absent filter',q(0,F)),('cov+order, absent filter',q(1,F))): print('  ',n,*go(s,True,4),flush=True)
