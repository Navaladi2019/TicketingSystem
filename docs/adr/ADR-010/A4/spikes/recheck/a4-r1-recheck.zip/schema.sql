CREATE ROLE nava_app LOGIN;
CREATE TABLE records (tenant_id uuid NOT NULL, id uuid NOT NULL, version bigint NOT NULL DEFAULT 0,
 entity_definition_id uuid, schema_version int, number text, state text, requester_id uuid, assignee_id uuid,
 assignment_group_id uuid, created_by uuid, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
 data jsonb NOT NULL DEFAULT '{}', causation_origin_id uuid, causation_depth smallint, org_unit_id uuid);
CREATE TABLE org_unit_closure (tenant_id uuid NOT NULL, ancestor_id uuid NOT NULL, descendant_id uuid NOT NULL,
 PRIMARY KEY (tenant_id, ancestor_id, descendant_id));
ALTER TABLE records ENABLE ROW LEVEL SECURITY; ALTER TABLE records FORCE ROW LEVEL SECURITY;
ALTER TABLE org_unit_closure ENABLE ROW LEVEL SECURITY; ALTER TABLE org_unit_closure FORCE ROW LEVEL SECURITY;
CREATE POLICY s ON records FOR SELECT TO nava_app USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
CREATE POLICY s ON org_unit_closure FOR SELECT TO nava_app USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
GRANT SELECT ON records, org_unit_closure TO nava_app;
ALTER DATABASE postgres SET jit=off;
-- A: tenant 1. S root s: 10111 units; o: 2000 other units (m=0)
CREATE TABLE ou (grp text, g int, id uuid);
INSERT INTO ou SELECT 's', g, md5('s'||g)::uuid FROM generate_series(0,10110) g UNION ALL SELECT 'o', g, md5('o'||g)::uuid FROM generate_series(0,1999) g;
INSERT INTO org_unit_closure WITH RECURSIVE c(grp,d,a) AS (SELECT grp,g,g FROM ou UNION ALL SELECT grp,d,(a-1)/10 FROM c WHERE a>0)
 SELECT md5('t1')::uuid, md5(grp||a)::uuid, md5(grp||d)::uuid FROM c;
VACUUM ANALYZE org_unit_closure;
