import subprocess,json,sys,re
P=['docker','exec','-i','tick1104-pgspec','psql','-qAtX','-U','pgadmin','-d','postgres','-v','ON_ERROR_STOP=1']
def psql(s,**v):
    a=P+sum([['-v',f'{k}={x}'] for k,x in v.items()],[])
    r=subprocess.run(a,input=s.encode(),capture_output=True)
    if r.returncode: raise SystemExit(r.stderr.decode())
    return r.stdout.decode()
import hashlib,uuid
h=lambda s:str(uuid.UUID(hashlib.md5(s.encode()).hexdigest()))
T,C,S=h('t1'),h('conc'),h('s0')
leaf=f"((r.org_unit_id IN (SELECT descendant_id FROM org_unit_closure WHERE tenant_id = '{T}'::uuid AND ancestor_id = ANY('{{{S}}}'::uuid[]))) IS TRUE)"
w=f"WHERE r.tenant_id='{T}'::uuid AND r.entity_definition_id='{C}'::uuid AND "
R=f"SELECT count(*) FROM (SELECT 1 FROM records r {w}{leaf} LIMIT 1001) c"
PAGE=f"SELECT r.id FROM records r {w}{leaf} ORDER BY r.updated_at DESC, r.id DESC LIMIT 51"
CC=f"SELECT count(*) FROM (SELECT 1 FROM org_unit_closure d CROSS JOIN LATERAL (SELECT 1 FROM records r {w} r.org_unit_id IS NOT NULL AND r.org_unit_id=d.descendant_id LIMIT 1001) x WHERE d.tenant_id='{T}'::uuid AND d.ancestor_id='{S}'::uuid LIMIT 1001) c"
def scan(n):
    if n.get('Relation Name')=='records':
        x=n['Node Type'];c=n.get('Plans',[{}])
        if x.startswith('Bitmap'):
            y=[k for k in c if 'Bitmap' in k['Node Type']][0]
            x+=' '+y.get('Index Name',y['Node Type'])
        else: x+=' '+n.get('Index Name','')
        return x, n.get('Index Cond',''), n['Actual Rows'],n.get('Rows Removed by Filter')
    for k in n.get('Plans',[]):
        r=scan(k)
        if r: return r
def run(q,pre='',reps=5):
    s=f"SET effective_cache_size='6GB';{pre} SET app.tenant_id='{T}'; SET ROLE nava_app; "+''.join(f"EXPLAIN (ANALYZE,BUFFERS,TIMING OFF,FORMAT JSON) {q};\nSELECT '~~~';" for _ in range(reps))
    ps=[json.loads(x)[0] for x in psql(s).split('~~~') if x.strip()]
    ts=sorted(p['Execution Time'] for p in ps[1:])
    p=ps[-1]['Plan']
    sc=scan(p)
    return dict(scan=sc[0],cost=p['Total Cost'],ms_med=round(ts[len(ts)//2],1),ms_max=ts[-1],buf=p['Shared Hit Blocks']+p['Shared Read Blocks'],read=p['Shared Read Blocks'])
if __name__=='__main__':
    cells=[tuple(map(int,c.split(','))) for c in sys.argv[1:]]
    for total,ne,tenants,width,scatter in cells:
        psql("DROP TABLE IF EXISTS keep; TRUNCATE records; ALTER TABLE records DROP CONSTRAINT IF EXISTS records_pkey, DROP CONSTRAINT IF EXISTS records_number_key; "+''.join(f"DROP INDEX IF EXISTS records_{i};" for i in 'list_updated list_created list_state list_group list_requester list_assignee list_group_state org_unit'.split()))
        psql(open('load.sql').read(),total=total,ne=ne,tenants=tenants,width=width,scatter=scatter)
        psql("SET maintenance_work_mem='512MB';"+open('idx.sql').read())
        mb=psql("select pg_relation_size('records')/1048576").strip()
        print(f"## rows={total} N_e={ne} tenants={tenants} width={width} scatter={scatter} heap={mb}MB",flush=True)
        for n,q,pre in (('R count',R,''),('R count,no seqscan',R,'SET enable_seqscan=off;'),('R count,plain index',R,'SET enable_seqscan=off;SET enable_bitmapscan=off;'),('R page',PAGE,''),('CC (A2)',CC,'')):
            print(f"  {n:22}",run(q,pre),flush=True)
