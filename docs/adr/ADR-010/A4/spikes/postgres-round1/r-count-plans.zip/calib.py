from plans import *
L=leaf(h('s0'))
# total,ne,own,width,scatter, plan seen by the original bench (unordered; ordered)
cells=[(800000,33366,800000,0,1,'Seq','index'),(1200000,33366,1200000,0,1,'index','-'),(250000,33366,250000,1024,1,'Seq','index'),(400000,33366,400000,1024,1,'index','-'),
(400000,33366,364000,0,1,'Seq','-'),(400000,33366,216000,0,1,'Seq','-'),(600000,33366,60000,0,1,'index','-'),(400000,20000,40000,1024,1,'index','-'),
(420000,20000,420000,0,0,'Seq','index'),(620000,20000,220000,0,0,'bitmap','index'),(400000,33366,52000,1024,1,'bitmap','index')]
for c in cells:
    load(*c[:5])
    print(c,flush=True)
    for n,o in (('today',0),('ordered',1)):
        q=cnt(L,o); print('  ',n,describe(explain(q)),'| no index:',describe(explain(q,NOIDX)),'| no seq:',describe(explain(q,'SET enable_seqscan=off;')),flush=True)
