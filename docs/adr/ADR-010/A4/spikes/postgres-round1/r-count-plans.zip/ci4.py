from plans import *
L=leaf(h('s0'))
for total,ne,own,sc in ((400000,33366,216000,1),(400000,33366,216000,0),(400000,33366,300000,0),(400000,33366,364000,0),(240000,20000,240000,0),(240000,20000,160000,0),(240000,20000,200000,0),(240000,20000,220000,0),(200000,33366,150000,0)):
    for rep in range(2):
        load(total,ne,own,0,sc)
        q=cnt(L,0); p=describe(explain(q)); b=describe(explain(q,'SET enable_seqscan=off;'))
        o=describe(explain(cnt(L,1))); a=describe(explain(cnt(L,1),'SET enable_seqscan=off;SET enable_indexscan=off;'))
        f=lambda x:(x[0].replace('Result','').replace('records_','')[-75:],x[1])
        print(total,ne,f'share={own/total:.2f} scatter={sc}','today',f(p),'best non-seq',f(b),'margin %.1f%%'%(100*(b[1]/p[1]-1)),'| ordered',f(o),'bitmap+sort',a[1],flush=True)
