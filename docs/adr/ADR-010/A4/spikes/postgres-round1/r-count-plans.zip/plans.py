# Plain EXPLAIN only. Loads 1/k of each cell, ANALYZEs it, then extends the heap and index
# files with sparse blocks to k x their size, so the planner sees the full-size relation.
import subprocess,json,hashlib,uuid,sys
N='tick1143-pgspec'
def psql(s,**v):
    a=['docker','exec','-i',N,'psql','-qAtX','-U','postgres','-d','postgres','-v','ON_ERROR_STOP=1']
    r=subprocess.run(a,input=s.encode(),capture_output=True)
    if r.returncode: raise SystemExit(r.stderr.decode()+s[:800])
    return r.stdout.decode()
h=lambda s:str(uuid.UUID(hashlib.md5(s.encode()).hexdigest()))
T,C=h('t1'),h('conc')
IDX="ALTER TABLE records ADD CONSTRAINT records_pkey PRIMARY KEY (tenant_id,id), ADD CONSTRAINT records_number_key UNIQUE (tenant_id,entity_definition_id,number);\n"+open('../bench/r-count-bench/idx.sql').read().split('\n',1)[1]
_s=open('../bench/r-count-bench/schema.sql').read()
RECORDS=_s[_s.index('CREATE TABLE records'):_s.index('CREATE TABLE org_unit_closure')]+"""ALTER TABLE records SET (autovacuum_enabled=off);
ALTER TABLE records ENABLE ROW LEVEL SECURITY; ALTER TABLE records FORCE ROW LEVEL SECURITY;
CREATE POLICY s ON records FOR SELECT TO nava_app USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
GRANT SELECT ON records TO nava_app;
"""
def load(total,ne,own,width=0,scatter=1,k=None,cover=False,pagerows=None):
    """own = rows of tenant 1 (>= ne). Other rows: 19 other tenants."""
    k=k or max(1,total//40000)
    psql("DROP TABLE IF EXISTS records CASCADE;"+RECORDS)
    data="'{}'::jsonb" if not width else f"jsonb_build_object('d', repeat(md5(g::text||'x'),{width//32}))"
    order='hashtext(g::text)' if scatter else 'g'
    psql(f"""INSERT INTO records SELECT CASE WHEN g<={own//k} THEN md5('t1') ELSE md5('t'||(2+g%19)) END::uuid, gen_random_uuid(),1,
 CASE WHEN g<={ne//k} THEN md5('conc') WHEN g<={own//k} THEN md5('d1') ELSE md5('d'||(2+g%19)) END::uuid,1,
 CASE WHEN g<={ne//k} THEN 'C-' ELSE 'P-' END||g, CASE WHEN g%2=0 THEN 'open' ELSE 'closed' END, md5('u'||g%997)::uuid, md5('a'||g%499)::uuid, md5('gr'||g%50)::uuid, md5('u'||g%997)::uuid,
 now()-((g::bigint*7919)%100003)*interval '1 s', now()-((g::bigint*104729)%1000003)*interval '1 s', {data}, NULL,0,
 CASE WHEN g<={ne//k} THEN md5('o'||g%2000) ELSE md5('s'||g%10111) END::uuid
FROM generate_series(1,{total//k}) g ORDER BY {order};
"""+IDX+("DROP INDEX records_list_updated; CREATE INDEX records_list_updated ON records (tenant_id, entity_definition_id, updated_at DESC, id DESC) INCLUDE (org_unit_id); VACUUM ANALYZE records;" if cover else ''))
    if k>1:
        psql("CHECKPOINT")
        rows=psql("SELECT pg_relation_filepath(c.oid), pg_relation_size(c.oid), c.relkind FROM pg_class c WHERE c.oid='records'::regclass OR c.oid IN (SELECT indexrelid FROM pg_index WHERE indrelid='records'::regclass)").split()
        cmds=[]
        for r in rows:
            p,s,kind=r.split('|'); s=int(s)//8192*k*8192
            assert s<2**30,(p,s)
            cmds.append(f"truncate -s {s} $PGDATA/{p}")
        r=subprocess.run(['docker','exec',N,'sh','-c',' && '.join(cmds)],capture_output=True); assert r.returncode==0,r.stderr
        psql(f"UPDATE pg_class SET relpages=relpages*{k},reltuples=reltuples*{k},relallvisible=relallvisible*{k} WHERE oid='records'::regclass OR oid IN (SELECT indexrelid FROM pg_index WHERE indrelid='records'::regclass)")
    return int(psql("SELECT pg_relation_size('records')/8192"))
def leaf(S): return f"((r.org_unit_id IN (SELECT descendant_id FROM org_unit_closure WHERE tenant_id = '{T}'::uuid AND ancestor_id = ANY('{{{S}}}'::uuid[]))) IS TRUE)"
W=f"WHERE r.tenant_id='{T}'::uuid AND r.entity_definition_id='{C}'::uuid AND "
O=" ORDER BY r.updated_at DESC, r.id DESC"
def arm(pred,order): return f"(SELECT 1 FROM records r {W}{pred}{O if order else ''} LIMIT 1001)"
def cnt(pred,order): return f"SELECT count(*) FROM {arm(pred,order)} c"
def union(arms): return "SELECT count(*) FROM (SELECT 1 FROM ("+" UNION ALL ".join(arms)+") u LIMIT 1001) c"
def explain(q,pre='',prep=None):
    s=f"SET effective_cache_size='6GB';SET app.tenant_id='{T}';{pre}SET ROLE nava_app;"
    s+= f"EXPLAIN (FORMAT JSON) {q};" if not prep else f"PREPARE p AS {q}; EXPLAIN (FORMAT JSON) EXECUTE p({prep});"
    return json.loads(psql(s))[0]['Plan']
def describe(p):
    out=[]
    def w(n):
        t=n['Node Type']
        if n.get('Parallel Aware'): t='Parallel '+t
        if n.get('Parent Relationship') in ('SubPlan','InitPlan'): return
        s=t
        if n.get('Index Name'): s+=' '+n['Index Name']
        if n.get('Relation Name')=='records' or t.startswith(('Sort','Gather','Incremental','Bitmap Index','Result')):
            s+=f"[est {n['Plan Rows']}]"
        if n.get('One-Time Filter'): s+=' OTF'
        out.append(s)
        for c in n.get('Plans',[]): w(c)
    w(p); return ' > '.join(x for x in out if not x.startswith(('Aggregate','Limit'))), round(p['Total Cost'])
NOIDX='SET enable_indexscan=off;SET enable_indexonlyscan=off;'
