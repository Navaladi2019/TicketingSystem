from plans import *
L=leaf(h('s0'))
def wal(n=2000):
    s=psql(f"""BEGIN; CHECKPOINT;""" if 0 else "CHECKPOINT;")
    p=json.loads(psql(f"""SET full_page_writes=off; BEGIN; EXPLAIN (ANALYZE,WAL,TIMING OFF,FORMAT JSON) UPDATE records SET updated_at=now()+random()*interval '1 s', version=version+1 WHERE ctid IN (SELECT ctid FROM records WHERE entity_definition_id='{C}' LIMIT {n}); ROLLBACK;""")) if 0 else None
def walq(n=2000):
    o=psql(f"BEGIN; EXPLAIN (ANALYZE,WAL,TIMING OFF,FORMAT JSON) UPDATE records SET updated_at=now()+random()*interval '1 s', version=version+1 WHERE ctid IN (SELECT ctid FROM records WHERE entity_definition_id='{C}' LIMIT {n}); ROLLBACK;")
    p=json.loads(o)[0]['Plan']; return p.get('WAL Records'),p.get('WAL FPI'),p.get('WAL Bytes')
psql("ALTER SYSTEM SET full_page_writes=off"); psql("SELECT pg_reload_conf()")
for c in ((40000,20000,40000,0,1),(40000,20000,40000,1024,1)):
    r=[]
    for cover in (False,True):
        load(*c,k=1,cover=cover)
        sz=psql("select pg_relation_size('records_list_updated')/40000.0, pg_relation_size('records')/40000.0, pg_indexes_size('records')/40000.0").strip()
        r.append((cover,sz,walq()))
    print(c,r,flush=True)
for c in ((800000,33366,800000,0,1),(250000,33366,250000,1024,1),(620000,20000,220000,0,0),(400000,33366,52000,1024,1),(400000,20000,40000,1024,1)):
    for cover in (False,True):
        load(*c,cover=cover)
        print(c,'cover' if cover else 'plain','ordered',describe(explain(cnt(L,1))),'| today-text',describe(explain(cnt(L,0))),'| ordered+state',describe(explain(cnt("r.state IN ('open','closed') AND "+L,1))),flush=True)
