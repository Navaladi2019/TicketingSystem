from plans import *
L=leaf(h('s0')); SEQ='SET enable_indexscan=off;SET enable_bitmapscan=off;'
def seqcost(q):  # seq arm with the closure read by its index-only scan: subtract nothing, read the Seq node's own plan when chosen
    return explain(q,'SET enable_bitmapscan=off;SET random_page_cost=4;')
for width,ts in ((0,(200000,400000,600000,800000,1000000)),(1024,(100000,150000,200000,250000,300000))):
    for t in ts:
        r=[]
        for rep in range(3):
            load(t,33366,t,width,1,k=max(1,t//(40000 if not width else 25000)))
            q=cnt(L,0); p=explain(q); b=explain(q,'SET enable_seqscan=off;')['Total Cost']
            r.append((describe(p)[0].split('>')[-1].strip().split('[')[0],round(p['Total Cost']),round(b)))
        print(width,t,r,flush=True)
