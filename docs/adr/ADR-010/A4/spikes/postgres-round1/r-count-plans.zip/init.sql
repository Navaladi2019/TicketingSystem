CREATE ROLE nava_app LOGIN;
CREATE TABLE org_unit_closure (tenant_id uuid NOT NULL, ancestor_id uuid NOT NULL, descendant_id uuid NOT NULL, PRIMARY KEY (tenant_id, ancestor_id, descendant_id));
ALTER TABLE org_unit_closure ENABLE ROW LEVEL SECURITY; ALTER TABLE org_unit_closure FORCE ROW LEVEL SECURITY;
CREATE POLICY s ON org_unit_closure FOR SELECT TO nava_app USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
GRANT SELECT ON org_unit_closure TO nava_app;
CREATE TABLE ou (grp text, g int);
INSERT INTO ou SELECT 's', g FROM generate_series(0,10110) g UNION ALL SELECT 'o', g FROM generate_series(0,1999) g UNION ALL SELECT 'w', g FROM generate_series(0,20221) g;
INSERT INTO org_unit_closure WITH RECURSIVE c(grp,d,a) AS (SELECT grp,g,g FROM ou UNION ALL SELECT grp,d,(a-1)/10 FROM c WHERE a>0)
 SELECT md5('t1')::uuid, md5(grp||a)::uuid, md5(grp||d)::uuid FROM c;
VACUUM ANALYZE org_unit_closure;
SELECT version();
