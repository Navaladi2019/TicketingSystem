from plans import *
L=leaf(h('s0')); L2=leaf(h('w0'))
SEQ='SET enable_indexscan=off;SET enable_bitmapscan=off;'   # closure falls to an index only scan or a seq scan
def rec(p):
    n=find(p,lambda x:x.get('Relation Name')=='records')
    return n
def short(p):
    d,c=describe(p); return d.replace('Result','').replace(' OTF','').replace('records_',''),c
def alt(q):   # cost of the best plan that is not a plain index scan / of a seq scan / of a bitmap
    return dict(seq=explain(q,SEQ)['Total Cost'], bitmap=explain(q,'SET enable_indexscan=off;SET enable_seqscan=off;')['Total Cost'])
def show(tag,q,pre='',prep=None): print('   ',tag,*short(explain(q,pre,prep)),flush=True)
which=sys.argv[1]
if which=='A':   # low ratio, small share: does the ordered count ever take Seq Scan + Sort?
    for width in (0,1024):
        for ne in (1500,5000,20000,33366):
            for ratio in (1.5,3,7,12,20):
                total=int(ne*ratio)
                for own in sorted({ne,(ne+total)//2,total}):
                    load(total,ne,own,width,1,k=max(1,total//30000))
                    t=short(explain(cnt(L,0))); o=short(explain(cnt(L,1)))
                    print(width,ne,ratio,f"share={own/total:.2f}",'| today',*t,'| ordered',*o,flush=True)
if which=='I':   # small shares
    for width in (0,1024):
        for ne in (20000,33366):
            for total,own in ((2000000,ne),(2000000,60000),(1000000,60000),(1000000,100000),(1000000,200000)):
                if width and total>1000000: total=900000
                if own/total<ne/total: continue
                load(total,ne,own,width,1,k=20)
                t=short(explain(cnt(L,0))); o=short(explain(cnt(L,1)))
                print(width,ne,total,f"share={own/total:.3f}",'| today',*t,'| ordered',*o,flush=True)
if which=='E':   # CI-4 world: contiguous one tenant, margin of Seq Scan over the index in the unordered count
    for ne in (20000,):
        for total in (60000,120000,180000,240000,300000,360000,420000,480000):
            for rep in range(2):
                load(total,ne,total,0,0,k=max(1,total//40000))
                q=cnt(L,0); p=explain(q); a=explain(q,SEQ)['Total Cost']; b=explain(q,'SET enable_seqscan=off;')
                o=cnt(L,1); po=explain(o); ao=explain(o,SEQ)['Total Cost']; bo=explain(o,'SET enable_indexscan=off;SET enable_seqscan=off;')['Total Cost']
                print(total,'unordered',short(p),'seq',round(a),'index',round(b['Total Cost']),'| ordered',short(po),'seq+sort',round(ao),'bitmap+sort',round(bo),flush=True)
if which=='D':
    X=h('u5')
    req=f"r.requester_id = '{X}'::uuid"
    neg=f"({req}) IS NOT TRUE"
    for c in ((620000,20000,220000,0,0),(420000,20000,420000,0,0),(250000,33366,250000,1024,1),(400000,33366,52000,1024,1)):
        load(*c); print(c,flush=True)
        for nm,LL in (('10111',L),('20222',L2)):
            for od in (0,1): show(f'{nm} unbranched ordered={od}',cnt(LL,od))
        q=cnt(L,1); print('    margins ordered 10111:',round(explain(q)['Total Cost']),{k:round(v) for k,v in alt(q).items()})
        q=cnt(L2,1); print('    margins ordered 20222:',round(explain(q)['Total Cost']),{k:round(v) for k,v in alt(q).items()})
        show('req + R, today',union([arm(req,0),arm(f"{L} AND {neg}",0)]))
        show('req + R, D3',union([arm(req,0),arm(f"{L} AND {neg}",1)]))
        show('two R arms, D3',union([arm(L,1),arm(f"{L2} AND NOT {L.replace(' IS TRUE)',')')}",1)]))
        for nm,f in (("state=1","r.state='open'"),("state in 2","r.state IN ('open','closed')"),("state in 2 rare","r.state IN ('open','nope')"),("assignee",f"r.assignee_id='{h('a5')}'::uuid"),("requester",req),("group",f"r.assignment_group_id='{h('gr5')}'::uuid"),("assignee in 2",f"r.assignee_id IN ('{h('a5')}'::uuid,'{h('a6')}'::uuid)"),("group+state",f"r.assignment_group_id='{h('gr5')}'::uuid AND r.state='open'"),("data contains","r.data @> '{\"d\":\"x\"}'")):
            show(f'filter {nm} today  ',cnt(f"{f} AND {L}",0)); show(f'filter {nm} ordered',cnt(f"{f} AND {L}",1))
if which=='G':
    for c in ((800000,33366,800000,0,1),(620000,20000,220000,0,0),(400000,33366,52000,1024,1),(400000,20000,40000,1024,1)):
        load(*c); print(c,flush=True)
        for od in (0,1):
            q=cnt(L,od); b=q.replace(f"'{T}'::uuid","$1::uuid").replace(f"'{C}'::uuid","$2::uuid").replace(f"'{{{h('s0')}}}'::uuid[]","$3::uuid[]")
            a=f"'{T}','{C}','{{{h('s0')}}}'"
            show(f'generic ordered={od}',b,'SET plan_cache_mode=force_generic_plan;',a)
            show(f'custom  ordered={od}',b,'SET plan_cache_mode=force_custom_plan;',a)
if which=='H':
    for c in ((800000,33366,800000,0,1),(250000,33366,250000,1024,1),(620000,20000,220000,0,0),(400000,33366,52000,1024,1),(400000,20000,40000,1024,1)):
        load(*c,k=10,cover=False)
        s0=psql("select pg_relation_size('records_list_updated'),pg_relation_size('records'),pg_indexes_size('records')").strip()
        pl0=short(explain(cnt(L,1)))
        psql("DROP INDEX records_list_updated; CREATE INDEX records_list_updated ON records (tenant_id, entity_definition_id, updated_at DESC, id DESC) INCLUDE (org_unit_id); VACUUM ANALYZE records;")
        s1=psql("select pg_relation_size('records_list_updated')").strip()
        print(c,'plain idx|heap|all idx',s0,'covering',s1,'ordered plain',pl0,'ordered cover',short(explain(cnt(L,1))),'unordered cover',short(explain(cnt(L,0))),'ordered cover+state filter',short(explain(cnt("r.state='open' AND "+L,1))),flush=True)
