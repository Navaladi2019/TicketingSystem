from plans import *
L=leaf(h('s0')); out={}
for width in (1024,):
  for ne in (9000,14000,20000,33366):
    for ratio in (2,3,4):
        total=int(ne*ratio)
        for own in sorted({ne,(ne+total)//2,total}):
            load(total,ne,own,width,1,k=1)
            p=explain(cnt(L,1)); d=describe(p)[0]
            fam='IDX' if 'Sort' not in d else ('SEQ+SORT' if 'Seq Scan' in d else 'BMP+SORT')
            t=describe(explain(cnt(L,0)))[0]
            print(width,ne,ratio,total,f"share={own/total:.2f} other={total-own}",fam,'today='+('SEQ' if 'Seq' in t else 'BMP' if 'Bitmap' in t else 'IDX'),flush=True)
